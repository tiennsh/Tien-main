package tacos.web.api;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import lombok.extern.slf4j.Slf4j;
import tacos.Order;
import tacos.data.OrderRepository;

@Slf4j
@Controller
@RequestMapping("/orders")
public class OrderController {

	private final OrderRepository orderRepo;

	@Autowired
	public OrderController(OrderRepository orderRepo) {

		this.orderRepo = orderRepo;

	}

	@PostMapping
	public String processOrder(Order order) {

		orderRepo.save(order);
		return "redirect:/";

	}
}